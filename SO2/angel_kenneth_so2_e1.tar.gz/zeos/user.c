#include <libc.h>

char buff[24];

int pid;

int add(int a, int b)
{
    return a + b;
}

extern int addAsm(int a, int b);

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */

    int c = addAsm(69, 420);

    int time = gettime();

    write(1, "asdf\n", 5);
    
    char *invalid = (char*)0;
    *invalid = 1;

    while(1) { }
}
