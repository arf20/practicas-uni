/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

union task_union task[NR_TASKS]
  __attribute__((__section__(".data.task")));
  
struct list_head freequeue, readyqueue;
int sys_unblock(int pid);
void writeMSR(long address, long value);
void aux_inner_task_switch(unsigned int new_kernel_esp);
int ticks_process;

struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  return list_entry( l, struct task_struct, list);
}

extern struct list_head blocked;
struct task_struct * idle_task;
struct task_struct * init_task;

int get_quantum (struct task_struct *t){
  return t->quantum;
}

void set_quantum (struct task_struct *t, int new_quantum){
  t->quantum = new_quantum;
}

/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
	return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
	return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}


int allocate_DIR(struct task_struct *t) 
{
	int pos;

	pos = ((int)t-(int)task)/sizeof(union task_union);

	t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 

	return 1;
}

void cpu_idle(void)
{
	__asm__ __volatile__("sti": : :"memory");
	
	// Part of the block/unblock tests, uncomment to test
	/*printk("I am idle\n");
	sys_unblock(1001);*/

	while(1)
	{
	;
	}
}

void init_idle (void)
{
  // Obtain an available task_union from the freequeue
  struct list_head * ptr = list_first(&freequeue);
  list_del(ptr);
  struct task_struct * pcb = list_head_to_task_struct(ptr);
  
  // Initialize attributes
  pcb->PID = 0;
  pcb->quantum = 10;
  pcb->pending_unblocks = 0;
  pcb->state = ST_READY; // Despite having the "ready" state, the idle process will never be queued in the ready queue
  INIT_LIST_HEAD(&pcb->children);
  pcb->parent = NULL;
  allocate_DIR(pcb);
  
  // Initialize execution context
  union task_union * tasku = (union task_union *) pcb;
  tasku->stack[KERNEL_STACK_SIZE - 1] = (unsigned long) cpu_idle;
  tasku->stack[KERNEL_STACK_SIZE - 2] = (unsigned long) 0;
  tasku->task.kernel_esp = (unsigned int) &(tasku->stack[KERNEL_STACK_SIZE - 2]);
  
  idle_task = pcb;
}

void init_task1(void)
{
  struct list_head * ptr = list_first(&freequeue);
  list_del(ptr);
  struct task_struct * pcb = list_head_to_task_struct(ptr);
  
  pcb->PID = 1;
  pcb->quantum = 10;
  pcb->pending_unblocks = 0;
  pcb->state = ST_RUN;
  INIT_LIST_HEAD(&pcb->children);
  pcb->parent = idle_task;
  list_add(&(pcb->anchor), &(idle_task->children));
  allocate_DIR(pcb);
  
  set_user_pages(pcb);
  
  union task_union * tasku = (union task_union *) pcb;
  writeMSR(0x175, KERNEL_ESP(tasku));
  tss.esp0 = KERNEL_ESP(tasku);
  
  set_cr3(get_DIR(pcb));
  init_task = pcb;
}


void init_sched()
{
  INIT_LIST_HEAD(&freequeue);
  INIT_LIST_HEAD(&readyqueue);
  INIT_LIST_HEAD(&blocked);
  for (int i = 0; i < NR_TASKS; i++)
  {
    list_add(&(task[i].task.list), &freequeue);
  }
}

void inner_task_switch(union task_union * new)
{
  writeMSR(0x175, KERNEL_ESP(new));
  tss.esp0 = KERNEL_ESP(new);
  set_cr3(get_DIR(&(new->task)));
  unsigned int new_kernel_esp = (new->task).kernel_esp;
  aux_inner_task_switch(new_kernel_esp);
}

void update_sched_data_rr(void)
{
  --ticks_process;
}

int needs_sched_rr(void)
{
  if (ticks_process > 0) return 0;
  else if (list_empty(&readyqueue)){
    ticks_process = current()->quantum;
    return 0;
  }
  return 1;
}

void update_process_state_rr(struct task_struct *t, struct list_head *dst_queue)
{
  struct list_head * ptr = &(t->list);
  if ((t->state == ST_RUN) && (dst_queue == &freequeue)){
    t->state = NULL;
  }
  else if (t->state == ST_READY || t->state == ST_BLOCKED){
    list_del(ptr);
    t->state = ST_RUN;
  }
  else t->state = ST_READY;
  if (dst_queue != NULL) list_add_tail(ptr, dst_queue);
}

void sched_next_rr(void)
{
  struct task_struct * pcb;
  if (list_empty(&readyqueue)) pcb = idle_task;
  else{
    struct list_head * ptr = list_first(&readyqueue);
    pcb = list_head_to_task_struct(ptr);
    update_process_state_rr(pcb, NULL);
  }
  ticks_process = pcb->quantum;
  task_switch((union task_union *) pcb);
}

void schedule(void)
{
  update_sched_data_rr();
  if (needs_sched_rr()){
    if (current() != idle_task) update_process_state_rr(current(), &readyqueue);
    sched_next_rr();
  }
}

struct task_struct* current()
{
  int ret_value;
  
  __asm__ __volatile__(
  	"movl %%esp, %0"
	: "=g" (ret_value)
  );
  return (struct task_struct*)(ret_value&0xfffff000);
}

