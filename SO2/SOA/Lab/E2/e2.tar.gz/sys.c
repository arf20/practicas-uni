/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1
#define tmp_buffer_size 1024
#define MIN(x, y) (x>y ? y:x)

extern int zeos_ticks;
extern struct list_head freequeue;
extern struct list_head readyqueue;
extern struct list_head blocked;
int start_pid = 1000;
char kbuffer[tmp_buffer_size];

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int ret_from_fork()
{
  return 0;
}

int sys_fork()
{
  // Obtain an available task_union from the freequeue
  if (list_empty(&freequeue)) return -14;
  struct list_head * ptr = list_first(&freequeue);
  list_del(ptr);
  struct task_struct * pcb = list_head_to_task_struct(ptr);
  union task_union * child_tu = (union task_union *) pcb;
  
  // Copy the parent's task_union to the child
  copy_data(current(), pcb, PAGE_SIZE);
  
  // Get a new page directory to store the child's address space
  allocate_DIR(pcb);
  
  // Search frames for child's data+stack
  int data[NUM_PAG_DATA];
  for (int i = 0; i < NUM_PAG_DATA; ++i){
     data[i] = alloc_frame();
     if (data[i] < 0){
  	while (i >= 0){
  	   --i;
  	   free_frame(i);
  	}
  	list_add(ptr, &freequeue);
  	return -12;
     }
  }
  
  // Initialize the child address space
  page_table_entry * PT_child = get_PT(pcb);
  page_table_entry * PT_parent = get_PT(current());
  for (int i = 0; i < NUM_PAG_KERNEL; ++i){
     set_ss_pag(PT_child, i, get_frame(PT_parent, i));
  }
  
  for (int i = 0; i < NUM_PAG_DATA; ++i){
     set_ss_pag(PT_child, i + NUM_PAG_KERNEL, data[i]);
  }
  
  int offset = NUM_PAG_KERNEL + NUM_PAG_DATA;
  for (int i = 0; i < NUM_PAG_CODE; ++i){
     set_ss_pag(PT_child, i + offset, get_frame(PT_parent, i + offset));
  }
  
  // Child inherits user data
  offset += NUM_PAG_CODE;
  for (int i = 0; i < NUM_PAG_DATA; ++i){
     set_ss_pag(PT_parent, i + offset, data[i]);
     copy_data((void *)((i + NUM_PAG_KERNEL) * PAGE_SIZE), (void *)((i + offset) * PAGE_SIZE), PAGE_SIZE);
     del_ss_pag(PT_parent, i + offset);
  }
  set_cr3(get_DIR(current()));
  
  // Assign child's PID and update lists
  pcb->PID = start_pid;
  pcb->pending_unblocks = 0;
  INIT_LIST_HEAD(&(pcb->children));
  pcb->parent = current();
  list_add(&(pcb->anchor), &(current()->children));
  ++start_pid;
  
  // Prepare child stack to restore process execution
  pcb->kernel_esp = (long unsigned int) &child_tu->stack[KERNEL_STACK_SIZE - 19];
  child_tu->stack[KERNEL_STACK_SIZE - 18] = (long unsigned int) &ret_from_fork;
  child_tu->stack[KERNEL_STACK_SIZE - 19] = 0;
  
  // Insert child into the ready list
  pcb->state = ST_READY;
  list_add_tail(ptr, &readyqueue);
  
  // Return the pid of the child process
  return pcb->PID;
}

void sys_exit()
{
  struct task_struct * pcb = current();
  page_table_entry * PT = get_PT(pcb);
  update_process_state_rr(pcb, &freequeue);
  
  pcb->PID = -1;
  pcb->quantum = -1;
  
  list_del(&(pcb->anchor));
  
  struct list_head * children = &(current()->children);
  struct list_head * ptr, * n;
  
  list_for_each_safe(ptr, n, children){
     ptr = list_first(children);
     list_del(ptr);
     list_add_tail(ptr, &(idle_task->children));
     ((struct task_struct *)((unsigned long) ptr & 0xfffff000))->parent = idle_task;
  }
  
  // No need to unmap the kernel entries in the Page Table, since all processes share the same
  /*for (int i = 0; i < NUM_PAG_KERNEL; ++i){
     del_ss_pag(PT, i);
  }*/
  
  int offset = NUM_PAG_KERNEL;
  for (int i = 0; i < NUM_PAG_DATA; ++i){
     free_frame(get_frame(PT, i + offset));
     del_ss_pag(PT, i + offset);
  }
  offset += NUM_PAG_DATA;
  for (int i = 0; i < NUM_PAG_CODE; ++i){
     del_ss_pag(PT, i + offset);
  }
  
  pcb->dir_pages_baseAddr = NULL;
  sched_next_rr();
}

void sys_block(){
   if (current()->pending_unblocks > 0){
     --current()->pending_unblocks;
   }
   else{
     struct list_head * ptr = &(current()->list);
     current()->state = ST_BLOCKED;
     list_add(ptr, &blocked);
     sched_next_rr();
   }
}

int sys_unblock(int pid){
   struct list_head * pos, * head;
   head = &(current()->children);
   list_for_each(pos, head){
      struct task_struct * pcb = (struct task_struct *)((unsigned long) pos & 0xfffff000);
      if (pcb->PID == pid){
      	if (pcb->state == ST_BLOCKED){
           pcb->state = ST_READY;
           list_del(&(pcb->list));
           list_add_tail(&(pcb->list), &readyqueue);
        }
        else pcb->pending_unblocks++;
        return 0;
      }
   }
   return -20;
}

int sys_write(int fd, char * buffer, int size)
{
  int check = check_fd(fd, ESCRIPTURA);
  if (check < 0) return check;
  if (buffer == NULL) return -2;
  if (size < 1) return -3;

  int characters = 0, result = 0; 
  while (size > 0) {
  	if (copy_from_user(buffer, kbuffer, tmp_buffer_size) < 0) return -1;
  	characters = sys_write_console(kbuffer, MIN(size, tmp_buffer_size));
  	if (characters < 0) return characters;
  	result += characters;
  	size -= tmp_buffer_size;	
  	buffer += tmp_buffer_size;
  }
  return result;
}

int sys_gettime()
{
  return zeos_ticks;
}
