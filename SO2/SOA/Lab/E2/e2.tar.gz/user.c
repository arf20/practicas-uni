#include <libc.h>

char buff[24];

int pid;
void perror();

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
     
  // TO AVOID POSSIBLE PROBLEMS (e.g: VARIABLE NAMES), ONLY UNCOMMENT ONE TEST AT ONCE
     
  // -------------------------------------------------------------------------------------------------------
  // TESTS FOR ALL E1 IMPLEMENTATIONS (Must execute ZeOS to test clock and keyboard interrupts)
  
  // Uncomment to get page fault
  /* char* p = 0;
  *p = 'x';*/
  
  // Uncomment to test write syscall
  // write(1, "Hello world\n", 12);
  
  /* Example perror function, uncomment to test. Test fd!=1, NULL buffer or size<0
     in the write syscall to see other possible errors */
  // perror();
  
  // Example gettime syscall, uncomment to test
  /*int n = 0;
  int ticks;
  char buffer[1];
  while(1) { 
    ++n;
    if (n == 100000000){
    	n = 0;
    	ticks = gettime();
  	itoa(ticks, buffer);
  	write(1, buffer, strlen(buffer));
  	write(1, "\n", 1);
    }
  }*/
  // --------------------------------------------------------------------------------------------------------
  // TESTS FOR ALL E2 IMPLEMENTATIONS
  
  // Example getpid syscall, uncomment to test
  /*char buffer2[1];
  pid = getpid();
  itoa(pid, buffer2);
  write(1, "My PID is: ", 11);
  write(1, buffer2, strlen(buffer2));
  write(1, "\n", 1);*/
  
  // Example fork syscall + task scheduling, uncomment to test
  // To test fork errors, make more than 8 forks (since there are max 10 PCBs, and 2 are already used by INIT and IDLE
  /*
  fork();
  int n = 0;
  while(1) { 
    ++n;
    if (n == 100000000){
    	n = 0;
    	pid = getpid();
  	itoa(pid, buff);
        write(1, "My PID is: ", 11);
        write(1, buff, strlen(buff)); 
        write(1, "\n", 1);
    }
  }*/
  
  // Example block/unblock/exit, uncomment to test
  /*pid = fork();
  if (pid != 0) fork();
  int n = 0;
  pid = getpid();
  if (pid == 1000) block();
  if (pid == 1001) block();
  unblock(1001);
  if (pid == 1) exit();
  unblock(1000);
  perror(); // Should display an error since PID=1000's parent is now IDLE, therefore PID=1001 cannot unblock him
  if (pid == 1001) block();
  // There is no process ready, therefore IDLE should take the CPU. Uncomment the code in IDLE that unblocks 1001 (remember, IDLE is now his parent)
  while(1) { 
    ++n;
    if (n == 100000000){
    	n = 0;
    	pid = getpid();
  	itoa(pid, buff);
        write(1, "My PID is: ", 11);
        write(1, buff, strlen(buff)); 
        write(1, "\n", 1);
    }
  }*/
  
  while(1) {
  	
  }
}
