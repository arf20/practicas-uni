#include <libc.h>

char buff[24];

int pid;
void perror();

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
     
  // -------------------------------------------------------------------------------------------------------
  // TESTS FOR ALL E1 IMPLEMENTATIONS (Must execute ZeOS to test clock and keyboard interrupts)
  
  /* Uncomment to get page fault
  char* p = 0;
  *p = 'x';*/
  
  write(1, "Hello world\n", 12); // Example write syscall
  
  /* Example perror function, test fd!=1, NULL buffer or size<0
     to see other possible errors */
  perror();
  
  // Example gettime syscall, uncomment to test
  /*int n = 0;
  int ticks;
  char buffer[1];
  while(1) { 
    ++n;
    if (n == 100000000){
    	n = 0;
    	ticks = gettime();
  	itoa(ticks, buffer);
  	write(1, buffer, strlen(buffer));
  	write(1, "\n", 1);
    }
  }*/
  // --------------------------------------------------------------------------------------------------------
  
  while(1) { }
}
