/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1
#define MIN(x, y) (x>y ? y:x)

extern int zeos_ticks;

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int sys_fork()
{
  int PID=-1;

  // creates the child process
  
  return PID;
}

void sys_exit()
{  
}

int tmp_buffer_size = 1024;

int sys_write(int fd, char * buffer, int size)
{
  int check = check_fd(fd, ESCRIPTURA);
  if (check < 0) return check;
  if (buffer == NULL) return -2;
  if (size < 1) return -3;
  
  char kbuffer[tmp_buffer_size];
  int characters = 0, result = 0; 
  while (size > 0) {
  	if (copy_from_user(buffer, kbuffer, tmp_buffer_size) < 0) return -1;
  	characters = sys_write_console(kbuffer, MIN(size, tmp_buffer_size));
  	if (characters < 0) return characters;
  	result += characters;
  	size -= tmp_buffer_size;	
  	buffer += tmp_buffer_size;
  }
  return result;
}

int sys_gettime()
{
  return zeos_ticks;
}
