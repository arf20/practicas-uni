package subastas;

public record Puja(String pujador, double cantidad) {
    
}
