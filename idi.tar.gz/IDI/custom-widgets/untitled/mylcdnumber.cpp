#include "mylcdnumber.h"

MyLCDNumber::MyLCDNumber(QObject *parent) {}
