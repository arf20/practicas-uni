#include "mylineedit.h"

MyLineEdit::MyLineEdit(QWidget *parent) {


}
